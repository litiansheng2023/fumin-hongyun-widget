# 富民鸿运金 Widget 0.1.0

独立 Android Kotlin MVP：加载富民银行公开 H5 页面，在页面前台运行时尝试从已渲染页面的可见 DOM 读取鸿运金2号买入价、卖出价，并保存到本机桌面小组件。

## 实现范围
- 仅允许加载 `https://open.fbank.com/pm2/dis-h5/gold/`。
- 不登录、不提交表单、不执行交易。
- 不调用隐藏 API、不抓取网络请求、不绕过签名、鉴权或访问控制。
- 只从含“鸿运金2号”“买入价”“卖出价”的已渲染文本区域提取数字。
- 本地缓存最近一次成功报价。
- 中型桌面 Widget 展示双价格和最近读取时间。
- 点击 Widget 打开官方 H5；读取成功后更新 Widget。

## 限制
这是用于验证 H5 页面 DOM 结构的 MVP。页面结构变化、WebView 兼容性和页面自动刷新机制都可能影响读取成功率。应用在前台页面打开时观察 DOM 变化并每5秒补充扫描；不保证应用后台或退出后继续刷新。Android 桌面组件不承诺秒级刷新。

如果银行页面规则或银行要求不允许自动化读取，应停止自动读取并改用银行明确授权的数据接口。

## 构建
GitHub Actions 工作流位于 `.github/workflows/build-apk.yml`。将本目录文件上传到 GitHub 仓库根目录，运行 Actions 的 `Build Android APK`，然后从 Artifacts 下载 `fumin-hongyun-widget-debug`。

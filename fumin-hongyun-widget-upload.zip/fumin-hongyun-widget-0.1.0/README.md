# 富民银行 · 鸿运金2号桌面行情组件 0.2.0

基于 0.1.0 已验证的官方页面可见文本识别逻辑升级。保留原鸿运金应用图标与官方页面地址。

## 0.2.0 更新
- 新增用户主动开启的 Android 前台服务，App退到后台后由服务独立持有 WebView 读取官方页面。
- 目标读取间隔为 5 秒；这是本地读取尝试间隔，不代表银行报价每 5 秒必然变化。
- 常驻通知显示监控状态、最新买入/卖出报价和更新时间，并提供停止监控操作。
- 新增 2×2 紧凑桌面组件；保留 4×2 完整组件。
- 组件显示最后读取时间，并区分正常、延迟、过期数据。
- 用户开启监控后记录状态，设备重启时尝试恢复；Android/厂商系统可能限制开机后启动前台服务，不能保证所有设备都能自动恢复。

## 数据读取范围
仅通过 WebView 读取 `https://open.fbank.com/pm2/dis-h5/gold/` 官方公开页面中可见的鸿运金2号买入价、卖出价文本。不读取登录凭证、不交易、不调用私有接口、不绕过访问控制。

## 构建
使用 JDK 17、Gradle 8.7、Android Gradle Plugin 8.6.1。GitHub Actions workflow 构建 `app-debug.apk`。

## 首次使用
1. 安装 APK 并打开应用。
2. 点击“开启持续监控”，允许通知权限。
3. 在桌面添加“富民银行 · 鸿运金2号”组件，选择 2×2 或 4×2。
4. 将应用加入手机厂商的后台运行/自启动白名单，并按系统提示允许后台活动。

## 限制
Android 前台服务比普通后台任务更适合持续读取，但系统省电策略、厂商后台管理、网络中断、WebView进程回收及官方页面自身更新频率都可能影响实际连续性。5秒是读取目标，不是实时行情或报价变化保证。若系统终止服务，重新打开应用可检查状态并再次开启监控。

## 0.2.1 Widget UI refinement
- Reworked both 4x2 and 2x2 widgets with a champagne-gold gradient, softer corners, balanced two-column prices and consistent unit labels.
- Added independent last-reading trend comparison for buy and sell quotes: rising is red with an up arrow; falling is green with a down arrow.
- Replaced verbose freshness copy with a compact HH:mm timestamp and a green/amber/gray status dot.
- The status dot is tappable and opens the app for detailed monitoring status.
- Android launcher widgets are rendered through RemoteViews and do not provide reliable continuous custom animation or true blur/glass rendering. The live quote/status updates provide the supported dynamic behavior without pretending a static widget animation is running.


## 0.2.4
- Fixed compact 2x2 widget sell-price clipping by removing asymmetric right-column inset and reducing compact price text size to 15sp.
- Slightly reduced compact widget outer padding to give both price columns more usable width.
- Kept quote parsing, monitoring, widget click behavior, and 4x2 layout unchanged.


## 0.2.5 visual refinement
- Refined compact 2x2 buy/sell spacing around the center divider while retaining a one-line full price.
- Updated both widget cards to a soft champagne gradient, warmer gold border, rounder corners, muted typography, and subtle elevation.
- Existing quote reader, monitoring service, and widget click behavior are retained.

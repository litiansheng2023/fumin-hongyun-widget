plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.fuminhongyunwidget"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.fuminhongyunwidget"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.2.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}

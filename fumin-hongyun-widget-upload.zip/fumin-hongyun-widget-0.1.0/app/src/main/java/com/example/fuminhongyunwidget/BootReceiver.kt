package com.example.fuminhongyunwidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || !GoldStore.isMonitoring(context)) return
        try {
            val service = Intent(context, GoldMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) {
            GoldStore.setError(context, "手机重启后未能自动恢复监控，请手动开启")
            GoldStore.setMonitoring(context, false)
        }
    }
}

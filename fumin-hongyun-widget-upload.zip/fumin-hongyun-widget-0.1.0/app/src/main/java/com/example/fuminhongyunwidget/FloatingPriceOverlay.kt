package com.example.fuminhongyunwidget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Compact translucent floating buy-price tag.
 * The transparent dark surface keeps the wallpaper/content visible beneath it.
 */
object FloatingPriceOverlay {
    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var priceView: TextView? = null
    private var contextRef: Context? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var downX = 0
    private var downY = 0
    private var moved = false

    fun show(context: Context) {
        if (!Settings.canDrawOverlays(context)) return
        if (overlay != null) {
            update(context)
            return
        }
        val app = context.applicationContext
        contextRef = app
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val card = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(app, 9), dp(app, 6), dp(app, 5), dp(app, 6))
            background = GradientDrawable().apply {
                // 40% opaque black: translucent like a lightweight market quote overlay.
                setColor(Color.argb(102, 18, 18, 18))
                cornerRadius = dp(app, 12).toFloat()
            }
            alpha = 0.88f
            elevation = dp(app, 2).toFloat()
        }

        val textColumn = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(app).apply {
            text = "鸿运金"
            textSize = 10f
            setTextColor(Color.argb(225, 255, 255, 255))
            setShadowLayer(dp(app, 2).toFloat(), 0f, 1f, Color.BLACK)
        }
        val price = TextView(app).apply {
            text = "等待行情"
            textSize = 16f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            includeFontPadding = false
            setShadowLayer(dp(app, 2).toFloat(), 0f, 1f, Color.BLACK)
        }
        priceView = price
        textColumn.addView(title)
        textColumn.addView(price)
        card.addView(textColumn, LinearLayout.LayoutParams(dp(app, 82), -2))

        val close = TextView(app).apply {
            text = "×"
            textSize = 17f
            setTextColor(Color.argb(210, 255, 255, 255))
            gravity = Gravity.CENTER
            setPadding(dp(app, 3), 0, dp(app, 1), 0)
            contentDescription = "关闭悬浮窗"
            setOnClickListener { hide(app, disablePreference = true) }
        }
        card.addView(close, LinearLayout.LayoutParams(dp(app, 17), -1))

        val display = app.resources.displayMetrics
        val savedX = GoldStore.overlayX(app)
        val savedY = GoldStore.overlayY(app)
        val lp = WindowManager.LayoutParams(
            -2, -2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (savedX * display.widthPixels).toInt().coerceAtLeast(0)
            y = (savedY * display.heightPixels).toInt().coerceAtLeast(dp(app, 80))
            // Keep the overlay itself translucent instead of an opaque card.
            alpha = 0.92f
        }
        params = lp

        card.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = p.x
                    downY = p.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > dp(app, 3) || abs(dy) > dp(app, 3)) moved = true
                    p.x = (downX + dx).coerceAtLeast(0)
                    p.y = (downY + dy).coerceAtLeast(dp(app, 24))
                    try { wm.updateViewLayout(card, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val metrics = app.resources.displayMetrics
                        val maxX = (metrics.widthPixels - card.width).coerceAtLeast(0)
                        p.x = if (p.x + card.width / 2 < metrics.widthPixels / 2) 0 else maxX
                        p.y = p.y.coerceIn(dp(app, 24), (metrics.heightPixels - card.height).coerceAtLeast(dp(app, 24)))
                        try { wm.updateViewLayout(card, p) } catch (_: Exception) {}
                        GoldStore.saveOverlayPosition(app, p.x, p.y, metrics.widthPixels, metrics.heightPixels)
                    } else {
                        val launch = Intent(app, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        app.startActivity(launch)
                    }
                    true
                }
                else -> true
            }
        }

        try {
            wm.addView(card, lp)
            overlay = card
            update(app)
        } catch (_: Exception) {
            overlay = null
            params = null
            priceView = null
        }
    }

    fun update(context: Context) {
        val price = GoldStore.values(context).first
        // The unit is intentionally omitted to keep the floating tag narrow.
        priceView?.text = price
        priceView?.setTextColor(
            when (GoldStore.trend(context, true)) {
                1 -> Color.rgb(245, 92, 92)
                -1 -> Color.rgb(64, 190, 132)
                else -> Color.WHITE
            }
        )
    }

    fun hide(context: Context, disablePreference: Boolean = false) {
        val view = overlay
        if (view != null) {
            try { windowManager?.removeView(view) } catch (_: Exception) {}
        }
        overlay = null
        params = null
        priceView = null
        if (disablePreference) GoldStore.setOverlayEnabled(context, false)
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}

package com.example.fuminhongyunwidget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Small draggable system overlay showing the latest official buy price.
 * Uses TYPE_APPLICATION_OVERLAY and stores its position in normalized screen coordinates.
 */
object FloatingPriceOverlay {
    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var priceView: TextView? = null
    private var contextRef: Context? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var downX = 0
    private var downY = 0
    private var moved = false

    fun show(context: Context) {
        if (!Settings.canDrawOverlays(context)) return
        if (overlay != null) {
            update(context)
            return
        }
        val app = context.applicationContext
        contextRef = app
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val card = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(app, 13), dp(app, 9), dp(app, 9), dp(app, 9))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(255, 250, 241), Color.rgb(247, 226, 202))
            ).apply {
                cornerRadius = dp(app, 24).toFloat()
                setStroke(dp(app, 1), Color.rgb(231, 207, 177))
            }
            elevation = dp(app, 7).toFloat()
        }

        val textColumn = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(app).apply {
            text = "鸿运金 · 买入价"
            textSize = 10f
            setTextColor(Color.rgb(139, 112, 78))
        }
        val price = TextView(app).apply {
            text = "等待行情"
            textSize = 17f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.rgb(141, 87, 45))
            maxLines = 1
        }
        priceView = price
        textColumn.addView(title)
        textColumn.addView(price)
        card.addView(textColumn, LinearLayout.LayoutParams(dp(app, 112), -2))

        val close = TextView(app).apply {
            text = "×"
            textSize = 19f
            setTextColor(Color.rgb(157, 126, 91))
            gravity = Gravity.CENTER
            setPadding(dp(app, 7), 0, dp(app, 4), 0)
            contentDescription = "关闭悬浮窗"
            setOnClickListener { hide(app, disablePreference = true) }
        }
        card.addView(close, LinearLayout.LayoutParams(-2, -1))

        val display = app.resources.displayMetrics
        val savedX = GoldStore.overlayX(app)
        val savedY = GoldStore.overlayY(app)
        val lp = WindowManager.LayoutParams(
            -2, -2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (savedX * display.widthPixels).toInt().coerceAtLeast(0)
            y = (savedY * display.heightPixels).toInt().coerceAtLeast(dp(app, 80))
        }
        params = lp

        card.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = p.x
                    downY = p.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (abs(dx) > dp(app, 3) || abs(dy) > dp(app, 3)) moved = true
                    p.x = (downX + dx).coerceAtLeast(0)
                    p.y = (downY + dy).coerceAtLeast(dp(app, 24))
                    try { wm.updateViewLayout(card, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val metrics = app.resources.displayMetrics
                        val maxX = (metrics.widthPixels - card.width).coerceAtLeast(0)
                        // Snap to the nearest screen edge after dragging.
                        p.x = if (p.x + card.width / 2 < metrics.widthPixels / 2) 0 else maxX
                        p.y = p.y.coerceIn(dp(app, 24), (metrics.heightPixels - card.height).coerceAtLeast(dp(app, 24)))
                        try { wm.updateViewLayout(card, p) } catch (_: Exception) {}
                        GoldStore.saveOverlayPosition(app, p.x, p.y, metrics.widthPixels, metrics.heightPixels)
                    } else {
                        val launch = Intent(app, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        app.startActivity(launch)
                    }
                    true
                }
                else -> true
            }
        }

        try {
            wm.addView(card, lp)
            overlay = card
            update(app)
        } catch (_: Exception) {
            overlay = null
            params = null
            priceView = null
        }
    }

    fun update(context: Context) {
        val price = GoldStore.values(context).first
        priceView?.text = if (price == "等待行情") price else "$price 元/克"
        priceView?.setTextColor(
            when (GoldStore.trend(context, true)) {
                1 -> Color.rgb(196, 65, 58)
                -1 -> Color.rgb(39, 132, 91)
                else -> Color.rgb(141, 87, 45)
            }
        )
    }

    fun hide(context: Context, disablePreference: Boolean = false) {
        val view = overlay
        if (view != null) {
            try { windowManager?.removeView(view) } catch (_: Exception) {}
        }
        overlay = null
        params = null
        priceView = null
        if (disablePreference) GoldStore.setOverlayEnabled(context, false)
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}

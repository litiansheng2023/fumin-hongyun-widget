package com.example.fuminhongyunwidget

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import org.json.JSONObject

class GoldMonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var pageReady = false
    private var reading = false
    private var stopped = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("正在启动官方行情读取…"))
        GoldStore.setMonitoring(this, true)
        createReader()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitor()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createReader() {
        if (webView != null) return
        val wv = WebView(this)
        webView = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.settings.javaScriptCanOpenWindowsAutomatically = false
        wv.settings.setSupportMultipleWindows(false)
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean =
                !QuoteReader.isOfficialPage(request.url.toString())
            override fun onPageFinished(view: WebView, url: String) {
                if (QuoteReader.isOfficialPage(url)) {
                    pageReady = true
                    GoldStore.setError(this@GoldMonitorService, "")
                    updateNotification("官方页面已加载，开始读取报价")
                    scheduleRead(500L)
                }
            }
            override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) {
                    pageReady = false
                    GoldStore.setError(this@GoldMonitorService, "官方页面连接失败")
                    updateNotification("官方页面连接失败，正在重试")
                    scheduleReload(5000L)
                }
            }
        }
        wv.loadUrl(QuoteReader.OFFICIAL_URL)
    }

    private fun scheduleRead(delay: Long) {
        if (stopped) return
        handler.removeCallbacks(readTask)
        handler.postDelayed(readTask, delay)
    }

    private val readTask = object : Runnable {
        override fun run() {
            val wv = webView
            if (stopped || wv == null || !pageReady || reading) {
                if (!stopped) scheduleRead(5000L)
                return
            }
            reading = true
            wv.evaluateJavascript(QuoteReader.visibleQuoteScript) { result ->
                reading = false
                if (stopped) return@evaluateJavascript
                try {
                    val decoded = org.json.JSONTokener(result ?: "null").nextValue() as? String
                    val obj = decoded?.let { JSONObject(it) }
                    val buy = obj?.optString("buy", "") ?: ""
                    val sell = obj?.optString("sell", "") ?: ""
                    val valid = Regex("^\\d{1,6}\\.\\d{1,4}$")
                    if (valid.matches(buy) && valid.matches(sell)) {
                        GoldStore.save(this@GoldMonitorService, buy, sell)
                        GoldStore.setError(this@GoldMonitorService, "")
                        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
                        updateNotification("买入 $buy · 卖出 $sell 元/克 · $stamp")
                    } else {
                        GoldStore.setError(this@GoldMonitorService, "暂未识别到鸿运金2号报价")
                        updateNotification("页面已连接，正在识别鸿运金2号报价…")
                    }
                } catch (_: Exception) {
                    GoldStore.setError(this@GoldMonitorService, "报价解析失败，正在重试")
                    updateNotification("报价解析失败，正在重试")
                }
                scheduleRead(5000L)
            }
        }
    }

    private fun scheduleReload(delay: Long) {
        handler.removeCallbacks(reloadTask)
        handler.postDelayed(reloadTask, delay)
    }

    private val reloadTask = Runnable {
        if (!stopped && webView != null) {
            pageReady = false
            webView?.loadUrl(QuoteReader.OFFICIAL_URL)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "鸿运金后台行情", NotificationManager.IMPORTANCE_LOW)
            channel.description = "显示持续行情读取状态和最新报价"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 11,
            Intent(this, GoldMonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle("富民银行 · 鸿运金2号")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText("后台持续读取官方页面（目标间隔 5 秒）\n$message"))
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "停止监控", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    }

    private fun stopMonitor() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        pageReady = false
        webView?.stopLoading()
        webView?.destroy()
        webView = null
        GoldStore.setMonitoring(this, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep running when the user removes the app from recents; the foreground service owns the task.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        webView?.stopLoading()
        webView?.destroy()
        webView = null
        if (GoldStore.isMonitoring(this)) GoldStore.setMonitoring(this, false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.example.fuminhongyunwidget.STOP_MONITOR"
        private const val CHANNEL_ID = "fumin_gold_monitor"
        private const val NOTIFICATION_ID = 2201
    }
}

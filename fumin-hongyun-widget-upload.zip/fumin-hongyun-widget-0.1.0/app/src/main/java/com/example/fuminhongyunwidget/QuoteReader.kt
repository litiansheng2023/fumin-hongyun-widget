package com.example.fuminhongyunwidget

/** Reads only the visible text rendered by the official public gold page. */
object QuoteReader {
    const val OFFICIAL_URL = "https://open.fbank.com/pm2/dis-h5/gold/"

    fun isOfficialPage(raw: String?): Boolean {
        if (raw.isNullOrBlank()) return false
        return try {
            val uri = android.net.Uri.parse(raw)
            uri.scheme == "https" && uri.host == "open.fbank.com" &&
                uri.path?.startsWith("/pm2/dis-h5/gold") == true &&
                uri.userInfo == null && uri.port in listOf(-1, 443)
        } catch (_: Exception) { false }
    }

    val visibleQuoteScript = """(function() {
      try {
        var leaves = Array.from(document.querySelectorAll('body *')).filter(function(el) {
          return el.children.length === 0 &&
            ((el.innerText || el.textContent || '').replace(/\s+/g, '').includes('鸿运金2号'));
        });
        for (var leaf of leaves) {
          var node = leaf;
          for (var depth = 0; depth < 10 && node; depth++, node = node.parentElement) {
            var text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ');
            if (text.includes('买入价') && text.includes('卖出价')) {
              var values = text.match(/\d{1,6}\.\d{1,4}/g) || [];
              if (values.length >= 2) return JSON.stringify({buy: values[0], sell: values[1]});
            }
          }
        }
      } catch (e) {}
      return null;
    })()"""
}

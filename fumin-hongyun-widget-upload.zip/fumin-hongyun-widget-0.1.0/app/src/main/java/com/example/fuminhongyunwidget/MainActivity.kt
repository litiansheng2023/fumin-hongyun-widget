package com.example.fuminhongyunwidget

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (::webView.isInitialized && isOfficialPage(webView.url)) readVisibleQuote()
            handler.postDelayed(this, 5000L)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply {
            text = "正在打开富民银行官方鸿运金页面…"
            textSize = 14f
            setPadding(16, 14, 16, 14)
        }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Only permit the exact official H5 origin and path in the top-level WebView.
                return !isOfficialPage(request.url.toString())
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (!isOfficialPage(url)) {
                    status.text = "仅允许访问富民银行官方鸿运金页面"
                    view.stopLoading()
                    view.loadUrl(OFFICIAL_URL)
                }
            }
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (isOfficialPage(url)) {
                    status.text = "官方页面已加载，正在读取鸿运金2号报价…"
                    readVisibleQuote()
                }
            }
        }
        root.addView(status, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        webView.loadUrl(OFFICIAL_URL)
    }

    private fun isOfficialPage(raw: String?): Boolean {
        if (raw.isNullOrBlank()) return false
        return try {
            val uri = android.net.Uri.parse(raw)
            uri.scheme == "https" && uri.host == "open.fbank.com" &&
                (uri.path == "/pm2/dis-h5/gold/" || uri.path == "/pm2/dis-h5/gold") &&
                uri.userInfo == null && uri.port in listOf(-1, 443)
        } catch (_: Exception) { false }
    }

    private fun readVisibleQuote() {
        if (!isOfficialPage(webView.url)) return
        // Return extracted visible DOM text through evaluateJavascript's callback.
        // No addJavascriptInterface is exposed to page scripts or iframes.
        val script = """(function(){
          function num(text,label){
            var e=label.replace(/[.*+?^${'$'}{}()|[\\]\\\\]/g,'\\\\$&');
            var m=text.match(new RegExp(e+'[^0-9]{0,24}([0-9,]+(?:\\\\.[0-9]{1,4})?)')) ||
                  text.match(new RegExp('([0-9,]+(?:\\\\.[0-9]{1,4})?)\\\\s*'+e));
            return m?m[1].replace(/,/g,''):null;
          }
          var nodes=Array.from(document.querySelectorAll('body *')).filter(function(n){
            return n.children.length===0 && (n.innerText||n.textContent||'').includes('鸿运金2号');
          });
          for(var n of nodes){var p=n;for(var i=0;i<8&&p;i++,p=p.parentElement){
            var t=(p.innerText||p.textContent||'').replace(/\\\\s+/g,' ');
            if(t.includes('买入价')&&t.includes('卖出价')){
              var b=num(t,'买入价'),s=num(t,'卖出价');
              if(b&&s)return JSON.stringify({buy:b,sell:s});
            }
          }} return null;
        })()"""
        webView.evaluateJavascript(script) { result ->
            if (result.isNullOrBlank() || result == "null") return@evaluateJavascript
            try {
                val decoded = org.json.JSONTokener(result).nextValue() as? String ?: return@evaluateJavascript
                val obj = JSONObject(decoded)
                val buy = obj.optString("buy")
                val sell = obj.optString("sell")
                if (buy.matches(Regex("^\\d{1,6}(?:\\.\\d{1,4})?$")) &&
                    sell.matches(Regex("^\\d{1,6}(?:\\.\\d{1,4})?$"))) {
                    GoldStore.save(this, buy, sell)
                    status.text = "鸿运金2号：买入 $buy 元/克 · 卖出 $sell 元/克"
                }
            } catch (_: Exception) { /* Ignore page structures that do not match. */ }
        }
    }

    override fun onResume() { super.onResume(); handler.removeCallbacks(poll); handler.post(poll) }
    override fun onPause() { handler.removeCallbacks(poll); super.onPause() }
    override fun onDestroy() {
        handler.removeCallbacks(poll)
        if (::webView.isInitialized) { webView.stopLoading(); webView.destroy() }
        super.onDestroy()
    }

    companion object { private const val OFFICIAL_URL = "https://open.fbank.com/pm2/dis-h5/gold/" }
}

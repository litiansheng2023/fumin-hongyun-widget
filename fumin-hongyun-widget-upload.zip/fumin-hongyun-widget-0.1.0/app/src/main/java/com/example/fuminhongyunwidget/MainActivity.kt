package com.example.fuminhongyunwidget

import android.app.ActivityManager
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var prices: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val refresh = object : Runnable {
        override fun run() {
            renderStatus()
            window.decorView.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(Color.rgb(250, 247, 241))
        }
        val title = TextView(this).apply {
            text = "富民银行 · 鸿运金2号"
            textSize = 22f; setTextColor(Color.rgb(105, 55, 20)); setTypeface(null, 1)
        }
        val subtitle = TextView(this).apply {
            text = "桌面行情监控"
            textSize = 13f; setTextColor(Color.rgb(130, 119, 107))
            setPadding(0, dp(5), 0, dp(22))
        }
        prices = TextView(this).apply {
            textSize = 18f; setTextColor(Color.rgb(40, 40, 40)); setLineSpacing(dp(8).toFloat(), 1f)
        }
        status = TextView(this).apply {
            textSize = 14f; setTextColor(Color.rgb(110, 100, 90))
            setPadding(0, dp(18), 0, dp(18))
        }
        startButton = Button(this).apply {
            text = "开启持续监控"
            setOnClickListener { requestNotificationAndStart() }
        }
        stopButton = Button(this).apply {
            text = "停止后台监控"
            setOnClickListener { stopService(Intent(this@MainActivity, GoldMonitorService::class.java)); GoldStore.setMonitoring(this@MainActivity, false); renderStatus() }
        }
        val note = TextView(this).apply {
            text = "开启后会在通知栏保留一条监控通知，并尝试每 5 秒读取一次富民银行官方页面。读取间隔不代表银行报价每 5 秒都会变化。请将本应用加入手机的后台运行/电池优化白名单，以降低系统限制。"
            textSize = 12f; setTextColor(Color.rgb(135, 125, 115)); setPadding(0, dp(18), 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(prices)
        root.addView(status)
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(50)))
        root.addView(stopButton, LinearLayout.LayoutParams(-1, dp(50)))
        root.addView(note)
        setContentView(root)
        renderStatus()
    }

    private fun requestNotificationAndStart() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        } else startMonitor()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) startMonitor()
    }

    private fun startMonitor() {
        val intent = Intent(this, GoldMonitorService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "正在启动后台行情服务…"
        } catch (_: Exception) {
            status.text = "启动失败。请保持应用在前台重试，并检查系统后台运行权限。"
        }
        renderStatus()
    }

    private fun renderStatus() {
        if (GoldStore.isMonitoring(this)) {
            val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val running = manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == GoldMonitorService::class.java.name }
            if (!running) GoldStore.setMonitoring(this, false)
        }
        val (buy, sell, time) = GoldStore.values(this)
        prices.text = "买入价  $buy 元/克\n卖出价  $sell 元/克"
        status.text = if (GoldStore.isMonitoring(this)) "● 后台监控已开启\n$time" else "○ 后台监控未开启\n$time"
        startButton.isEnabled = !GoldStore.isMonitoring(this)
        stopButton.isEnabled = GoldStore.isMonitoring(this)
    }

    override fun onResume() { super.onResume(); window.decorView.removeCallbacks(refresh); window.decorView.post(refresh) }
    override fun onPause() { window.decorView.removeCallbacks(refresh); super.onPause() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

package com.example.fuminhongyunwidget

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            if (::webView.isInitialized && isOfficialPage(webView.url)) {
                readVisibleQuote()
            }
            handler.postDelayed(this, 5000L)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply {
            text = "正在打开富民银行官方鸿运金页面…"
            textSize = 14f
            setPadding(16, 14, 16, 14)
        }

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress >= 100 && isOfficialPage(view.url)) {
                    status.text = "官方页面已打开，正在识别鸿运金2号报价…"
                    handler.postDelayed({ readVisibleQuote() }, 800L)
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return !isOfficialPage(request.url.toString())
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (!isOfficialPage(url)) {
                    status.text = "仅允许访问富民银行官方鸿运金页面"
                    view.stopLoading()
                    view.loadUrl(OFFICIAL_URL)
                } else {
                    status.text = "正在加载富民银行官方鸿运金页面…"
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (isOfficialPage(url)) {
                    status.text = "官方页面已打开，正在识别鸿运金2号报价…"
                    handler.postDelayed({ readVisibleQuote() }, 800L)
                }
            }
        }

        root.addView(status, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        webView.loadUrl(OFFICIAL_URL)
    }

    private fun isOfficialPage(raw: String?): Boolean {
        if (raw.isNullOrBlank()) return false
        return try {
            val uri = android.net.Uri.parse(raw)
            uri.scheme == "https" &&
                uri.host == "open.fbank.com" &&
                uri.path?.startsWith("/pm2/dis-h5/gold") == true &&
                uri.userInfo == null &&
                uri.port in listOf(-1, 443)
        } catch (_: Exception) {
            false
        }
    }

    private fun readVisibleQuote() {
        if (!isOfficialPage(webView.url)) return

        // Read only visible text in the official page's DOM.
        // The 2号 card displays each price before its label, so collect decimal
        // price values from the smallest ancestor containing both price labels.
        val script = """(function() {
          try {
            var leaves = Array.from(document.querySelectorAll('body *')).filter(function(el) {
              return el.children.length === 0 &&
                ((el.innerText || el.textContent || '').replace(/\s+/g, '').includes('鸿运金2号'));
            });
            for (var leaf of leaves) {
              var node = leaf;
              for (var depth = 0; depth < 10 && node; depth++, node = node.parentElement) {
                var text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ');
                if (text.includes('买入价') && text.includes('卖出价')) {
                  var values = text.match(/\d{1,6}\.\d{1,4}/g) || [];
                  if (values.length >= 2) {
                    return JSON.stringify({buy: values[0], sell: values[1]});
                  }
                }
              }
            }
          } catch (e) {}
          return null;
        })()"""

        webView.evaluateJavascript(script) { result ->
            if (result.isNullOrBlank() || result == "null") {
                status.text = "页面已打开，暂未识别到鸿运金2号报价，正在重试…"
                return@evaluateJavascript
            }
            try {
                val decoded = org.json.JSONTokener(result).nextValue() as? String
                    ?: return@evaluateJavascript
                val obj = JSONObject(decoded)
                val buy = obj.optString("buy")
                val sell = obj.optString("sell")
                val valid = Regex("^\\d{1,6}\\.\\d{1,4}$")
                if (valid.matches(buy) && valid.matches(sell)) {
                    GoldStore.save(this, buy, sell)
                    status.text = "鸿运金2号：买入 $buy 元/克 · 卖出 $sell 元/克"
                } else {
                    status.text = "页面已打开，报价格式暂未识别，正在重试…"
                }
            } catch (_: Exception) {
                status.text = "页面已打开，报价解析失败，正在重试…"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val OFFICIAL_URL = "https://open.fbank.com/pm2/dis-h5/gold/"
    }
}

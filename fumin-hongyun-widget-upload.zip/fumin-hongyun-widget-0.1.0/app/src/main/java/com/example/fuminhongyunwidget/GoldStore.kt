package com.example.fuminhongyunwidget

import android.content.Context
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GoldStore {
    private const val PREFS = "fumin_hongyun_quote"
    fun save(context: Context, buy: String, sell: String) {
        val valid = Regex("^\\d{1,6}(?:\\.\\d{1,4})?$")
        if (!valid.matches(buy) || !valid.matches(sell)) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("buy", buy).putString("sell", sell)
            .putLong("updated", System.currentTimeMillis()).apply()
        updateWidgets(context)
    }
    fun values(context: Context): Triple<String, String, String> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val buy = p.getString("buy", null) ?: "等待读取"
        val sell = p.getString("sell", null) ?: "等待读取"
        val time = p.getLong("updated", 0L)
        val label = if (time == 0L) "打开应用加载官方行情"
            else "最近读取 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date(time))
        return Triple(buy, sell, label)
    }
    fun updateWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, GoldWidgetProvider::class.java))
        ids.forEach { GoldWidgetProvider.update(context, manager, it) }
    }
}

package com.example.fuminhongyunwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GoldStore {
    private const val PREFS = "fumin_hongyun_quote"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, buy: String, sell: String) {
        val valid = Regex("^\\d{1,6}(?:\\.\\d{1,4})?$")
        if (!valid.matches(buy) || !valid.matches(sell)) return
        prefs(context).edit().putString("buy", buy).putString("sell", sell)
            .putLong("updated", System.currentTimeMillis()).putString("last_error", "").apply()
        updateWidgets(context)
    }

    fun values(context: Context): Triple<String, String, String> {
        val p = prefs(context)
        val buy = p.getString("buy", null) ?: "等待行情"
        val sell = p.getString("sell", null) ?: "等待行情"
        val time = p.getLong("updated", 0L)
        val label = if (time == 0L) "尚未读取官方报价" else {
            val age = (System.currentTimeMillis() - time) / 1000
            val stamp = SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date(time))
            when {
                age > 120 -> "数据已过期 · $stamp"
                age > 30 -> "更新延迟 · $stamp"
                else -> "更新于 $stamp"
            }
        }
        return Triple(buy, sell, label)
    }

    fun updatedAt(context: Context): Long = prefs(context).getLong("updated", 0L)
    fun isMonitoring(context: Context): Boolean = prefs(context).getBoolean("monitoring", false)
    fun setMonitoring(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("monitoring", enabled).apply()
        updateWidgets(context)
    }
    fun setError(context: Context, message: String) {
        prefs(context).edit().putString("last_error", message).apply()
    }
    fun error(context: Context): String = prefs(context).getString("last_error", "") ?: ""

    fun updateWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        listOf(
            GoldWidgetProvider::class.java,
            GoldWidgetCompactProvider::class.java
        ).forEach { provider ->
            val ids = manager.getAppWidgetIds(ComponentName(context, provider))
            ids.forEach { id ->
                if (provider == GoldWidgetProvider::class.java) GoldWidgetProvider.update(context, manager, id)
                else GoldWidgetCompactProvider.update(context, manager, id)
            }
        }
    }
}

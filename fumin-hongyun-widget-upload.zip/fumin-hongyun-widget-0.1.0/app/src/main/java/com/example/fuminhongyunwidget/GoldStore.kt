package com.example.fuminhongyunwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GoldStore {
    private const val PREFS = "fumin_hongyun_quote"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, buy: String, sell: String) {
        val valid = Regex("^\\d{1,6}(?:\\.\\d{1,4})?$")
        if (!valid.matches(buy) || !valid.matches(sell)) return
        val p = prefs(context)
        val oldBuy = p.getString("buy", null)?.toDoubleOrNull()
        val oldSell = p.getString("sell", null)?.toDoubleOrNull()
        val newBuy = buy.toDoubleOrNull() ?: return
        val newSell = sell.toDoubleOrNull() ?: return
        val buyTrend = when { oldBuy == null || newBuy == oldBuy -> 0; newBuy > oldBuy -> 1; else -> -1 }
        val sellTrend = when { oldSell == null || newSell == oldSell -> 0; newSell > oldSell -> 1; else -> -1 }
        p.edit().putString("buy", buy).putString("sell", sell)
            .putInt("buy_trend", buyTrend).putInt("sell_trend", sellTrend)
            .putLong("updated", System.currentTimeMillis()).putString("last_error", "").apply()
        updateWidgets(context)
    }

    fun values(context: Context): Triple<String, String, String> {
        val p = prefs(context)
        val buy = p.getString("buy", null) ?: "等待行情"
        val sell = p.getString("sell", null) ?: "等待行情"
        val time = p.getLong("updated", 0L)
        val label = if (time == 0L) "--:--" else SimpleDateFormat("HH:mm", Locale.CHINA).format(Date(time))
        return Triple(buy, sell, label)
    }

    fun trend(context: Context, isBuy: Boolean): Int =
        prefs(context).getInt(if (isBuy) "buy_trend" else "sell_trend", 0)

    fun statusColor(context: Context): Int {
        val updated = updatedAt(context)
        if (updated <= 0L) return android.graphics.Color.GRAY
        val age = (System.currentTimeMillis() - updated) / 1000
        return when {
            age <= 30 -> android.graphics.Color.rgb(43, 145, 91)
            age <= 120 -> android.graphics.Color.rgb(207, 157, 57)
            else -> android.graphics.Color.GRAY
        }
    }

    fun updatedAt(context: Context): Long = prefs(context).getLong("updated", 0L)
    fun isMonitoring(context: Context): Boolean = prefs(context).getBoolean("monitoring", false)
    fun setMonitoring(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("monitoring", enabled).apply()
        updateWidgets(context)
    }
    fun setError(context: Context, message: String) {
        prefs(context).edit().putString("last_error", message).apply()
    }
    fun error(context: Context): String = prefs(context).getString("last_error", "") ?: ""

    fun updateWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        listOf(
            GoldWidgetProvider::class.java,
            GoldWidgetCompactProvider::class.java
        ).forEach { provider ->
            val ids = manager.getAppWidgetIds(ComponentName(context, provider))
            ids.forEach { id ->
                if (provider == GoldWidgetProvider::class.java) GoldWidgetProvider.update(context, manager, id)
                else GoldWidgetCompactProvider.update(context, manager, id)
            }
        }
    }
}

package com.example.fuminhongyunwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

private fun priceLabel(value: String, trend: Int): String = when (trend) {
    1 -> "$value ↑"
    -1 -> "$value ↓"
    else -> value
}

private fun trendColor(trend: Int): Int = when (trend) {
    1 -> Color.rgb(196, 65, 58)
    -1 -> Color.rgb(39, 132, 91)
    else -> Color.rgb(128, 91, 43)
}

private fun openAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
    val intent = Intent(context, MainActivity::class.java).apply {
        action = "com.example.fuminhongyunwidget.OPEN_FROM_WIDGET_$requestCode"
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }
    return PendingIntent.getActivity(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun renderWidget(context: Context, manager: AppWidgetManager, id: Int, layoutId: Int, requestCode: Int) {
    val views = RemoteViews(context.packageName, layoutId)
    val (buy, sell, time) = GoldStore.values(context)
    val buyTrend = GoldStore.trend(context, true)
    val sellTrend = GoldStore.trend(context, false)
    views.setTextViewText(R.id.buy_price, priceLabel(buy, buyTrend))
    views.setTextViewText(R.id.sell_price, priceLabel(sell, sellTrend))
    views.setTextColor(R.id.buy_price, trendColor(buyTrend))
    views.setTextColor(R.id.sell_price, trendColor(sellTrend))
    views.setTextViewText(R.id.update_time, time)
    views.setTextColor(R.id.status_dot, GoldStore.statusColor(context))

    // Attach the same explicit launch PendingIntent to the root and visible child views.
    // This makes the whole card reliably tappable across common Android launchers.
    val open = openAppPendingIntent(context, requestCode + id)
    views.setOnClickPendingIntent(R.id.widget_root, open)
    views.setOnClickPendingIntent(R.id.status_dot, open)
    views.setOnClickPendingIntent(R.id.buy_price, open)
    views.setOnClickPendingIntent(R.id.sell_price, open)
    views.setOnClickPendingIntent(R.id.update_time, open)
    manager.updateAppWidget(id, views)
}

class GoldWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { renderWidget(context, manager, it, R.layout.gold_widget, 1000) }
    }

    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            renderWidget(context, manager, id, R.layout.gold_widget, 1000)
        }
    }
}

class GoldWidgetCompactProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { renderWidget(context, manager, it, R.layout.gold_widget_compact, 2000) }
    }

    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            renderWidget(context, manager, id, R.layout.gold_widget_compact, 2000)
        }
    }
}

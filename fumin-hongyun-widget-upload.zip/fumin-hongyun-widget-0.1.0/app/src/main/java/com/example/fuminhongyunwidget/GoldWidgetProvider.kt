package com.example.fuminhongyunwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

private fun priceLabel(value: String, trend: Int): String = when (trend) {
    1 -> "$value  ↑"
    -1 -> "$value  ↓"
    else -> value
}

private fun trendColor(trend: Int): Int = when (trend) {
    1 -> Color.rgb(196, 65, 58) // 涨：红
    -1 -> Color.rgb(39, 132, 91) // 跌：绿
    else -> Color.rgb(128, 91, 43)
}

class GoldWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.gold_widget)
            val (buy, sell, time) = GoldStore.values(context)
            val buyTrend = GoldStore.trend(context, true)
            val sellTrend = GoldStore.trend(context, false)
            views.setTextViewText(R.id.buy_price, priceLabel(buy, buyTrend))
            views.setTextViewText(R.id.sell_price, priceLabel(sell, sellTrend))
            views.setTextColor(R.id.buy_price, trendColor(buyTrend))
            views.setTextColor(R.id.sell_price, trendColor(sellTrend))
            views.setTextViewText(R.id.update_time, time)
            views.setTextColor(R.id.status_dot, GoldStore.statusColor(context))
            val pending = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            views.setOnClickPendingIntent(R.id.status_dot, pending)
            manager.updateAppWidget(id, views)
        }
    }
}

class GoldWidgetCompactProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.gold_widget_compact)
            val (buy, sell, time) = GoldStore.values(context)
            val buyTrend = GoldStore.trend(context, true)
            val sellTrend = GoldStore.trend(context, false)
            views.setTextViewText(R.id.buy_price, priceLabel(buy, buyTrend))
            views.setTextViewText(R.id.sell_price, priceLabel(sell, sellTrend))
            views.setTextColor(R.id.buy_price, trendColor(buyTrend))
            views.setTextColor(R.id.sell_price, trendColor(sellTrend))
            views.setTextViewText(R.id.update_time, time)
            views.setTextColor(R.id.status_dot, GoldStore.statusColor(context))
            val pending = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            views.setOnClickPendingIntent(R.id.status_dot, pending)
            manager.updateAppWidget(id, views)
        }
    }
}

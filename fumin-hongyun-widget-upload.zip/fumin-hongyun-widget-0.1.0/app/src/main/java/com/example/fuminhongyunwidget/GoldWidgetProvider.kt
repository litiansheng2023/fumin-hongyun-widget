package com.example.fuminhongyunwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class GoldWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.gold_widget)
            val (buy, sell, time) = GoldStore.values(context)
            views.setTextViewText(R.id.buy_price, buy)
            views.setTextViewText(R.id.sell_price, sell)
            views.setTextViewText(R.id.update_time, time)
            views.setTextViewText(R.id.monitor_state, if (GoldStore.isMonitoring(context)) "● 后台监控中" else "○ 未开启监控")
            val pending = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}

class GoldWidgetCompactProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }
    companion object {
        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.gold_widget_compact)
            val (buy, sell, time) = GoldStore.values(context)
            views.setTextViewText(R.id.buy_price, buy)
            views.setTextViewText(R.id.sell_price, sell)
            views.setTextViewText(R.id.update_time, time)
            val pending = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
